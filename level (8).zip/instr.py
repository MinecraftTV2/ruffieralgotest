
win_x, win_y = 200, 100
win_width, win_height = 1000, 600

txt_hello = ''
txt_next = ''
txt_instruction = '' 
txt_title = ''
txt_name = ''
txt_hintname = ""
txt_hintage = ""
txt_test1 = ''
txt_test2 = ''
txt_test3 = ''
txt_sendresults = ''
txt_hinttest1 = '0'
txt_hinttest2 = '0'
txt_hinttest3 = '0'
txt_starttest1 = ''
txt_starttest2 = ''
txt_starttest3 = ''

txt_age = ''
txt_finalwin = ''
txt_index = ''
txt_workheart = ''